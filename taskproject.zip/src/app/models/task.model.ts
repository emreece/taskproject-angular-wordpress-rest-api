export class taskData {
    title: {rendered: string};
    content: string;
    taskID: number;
    status: string;
    authorID: number;
    userID: number; 
    constructor(data) {
        this.title = data.title;
        this.taskID = data.id;
        this.content = data.content.rendered;
    }
}