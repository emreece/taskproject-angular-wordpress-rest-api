export class userData {
    username: string;
    userID: number;

    constructor() { 
        this.username = '';
        this.userID = 0;
    }
}