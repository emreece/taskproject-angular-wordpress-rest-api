import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-task-detail',
  templateUrl: './my-task-detail.component.html',
  styleUrls: ['./my-task-detail.component.css']
})
export class MyTaskDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
