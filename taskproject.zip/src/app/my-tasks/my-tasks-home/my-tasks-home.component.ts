import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { taskData } from 'src/app/models/task.model';
import { userData } from 'src/app/models/user.model';
import { LoginService } from 'src/app/services/login.service';
import { userTasksService } from 'src/app/services/userTasks.service';

@Component({
  selector: 'app-my-tasks-home',
  templateUrl: './my-tasks-home.component.html',
  styleUrls: ['./my-tasks-home.component.css']
})
export class MyTasksHomeComponent implements OnInit {
  userData = new userData();
  tasks: Array<taskData>
  constructor(private loService: LoginService, private router: Router, private uTasksService: userTasksService) { }

  ngOnInit(): void { 
    this.loService.getMyInformations().subscribe(
      res => {
       /* this.personModel.name = res.name; this.personModel.image = res.avatar_urls[96] */
       this.userData.username = res.name;
       this.userData.userID = res.id;
       this.loService.userDataChanged.next(res.name);
       this.uTasksService.getMyTasks().subscribe(
        res => {
          this.tasks = res;
        })
      },
      error => {
          console.log("error", error);
          this.router.navigateByUrl('/');
      }
    )
  }

}
