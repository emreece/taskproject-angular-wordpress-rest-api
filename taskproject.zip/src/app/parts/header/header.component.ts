import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Input() 'isLogin':boolean;
  @Input() 'userName' : string = '';
  constructor(private router: Router, private loService: LoginService) { }

  ngOnInit(): void {
     
  }
  onLogout(): void {
    this.isLogin = !this.loService.logout();
    if(!this.isLogin) {
      this.router.navigate(['/']);
    }
  }
}
