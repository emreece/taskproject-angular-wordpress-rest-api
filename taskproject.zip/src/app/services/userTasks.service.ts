import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
// import { Person } from 'src/Model/person';
import { Observable, Subject, throwError } from 'rxjs';
import { retry, catchError, map } from 'rxjs/operators';
import { LoginService } from './login.service';
import { taskData } from '../models/task.model';

@Injectable({ providedIn: 'root' })
export class userTasksService {
    myTasksUrl: string = 'http://localhost/wpjwt/wp-json/wp/v2/posts';
    tasks : Array<taskData> = [];
    constructor(private httpClient: HttpClient, private loService: LoginService) { }

    public getMyTasks() {
        let that = this

        let httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + this.loService.GetToken()
            }),
            observe: 'response' as 'body',
        }
        return this.httpClient.get<any>(this.myTasksUrl+'?status=draft,publish,trash', httpOptions)
            .pipe(
                map(response => {
                    console.log(response.body);
                    response.body.forEach(function(task){
                        task = new taskData({'title': task.title, 'id': task.id, 'content': task.content});
                        that.tasks.push(task)
                    });
                    console.log('tasks');
                    console.log(this.tasks);
                    return this.tasks;
                }),
                retry(1),
                // catchError(this.errorHandel)
            )
    }

    errorHandel(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // Get client-side error
            errorMessage = error.error.message;
        } else {
            // Get server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        return throwError(errorMessage);
    }
    handleAuthError(err) {
        if(err.status === 401 || err.status === 403) {
            return throwError(err.status);
        }
    }

}